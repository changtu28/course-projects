#include "pio.h"
#include "system.h"


int main (void)
{
    system_init ();

    while (1)
    {

        /* TODO.  Use PIO module to turn on LEDs in
           LED matrix.  */

    }
}

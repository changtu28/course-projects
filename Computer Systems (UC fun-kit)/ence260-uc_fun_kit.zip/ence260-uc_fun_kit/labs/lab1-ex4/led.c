#include "pio.h"
#include "led.h"


/** Turn LED1 on.  */
void led_on (void)
{
    /* TODO!  */
}


/** Turn LED1 off.  */
void led_off (void)
{
    /* TODO!  */
}


/** Initialise LED1.  */
void led_init (void)
{
    /* TODO!  */
}

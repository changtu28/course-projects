/** 
 * @file game.c
 * @author  Caleb Wenborn (cwe55)  
 *          Chang Tu (ctu28)  
 * Team number : 422
 *
 * @date   16 October 2018
**/

/* Modules */
#include "system.h"
#include "pio.h"
#include "pacer.h"
#include "navswitch.h"
#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font3x5_1.h"

#define PIEZO1_PIO PIO_DEFINE (PORT_D, 4)
#define PIEZO2_PIO PIO_DEFINE (PORT_D, 6)
#define TEST_PIO PIO_DEFINE (PORT_D, 3)

/* Named constants */
#define LOOP_RATE 10000
#define PACER_RATE 500
#define MESSAGE_RATE 10

int TONE_FREQUENCY = 100;
/* Player‘s initialization */
uint8_t bitmap_shape = 0;
uint8_t words = 0;
char player_1_choice = 'N';
char player_2_choice = 'N';

/* bitmap initialization */
uint8_t player_1 = 0;
uint8_t player_2 = 0;
static char* choice_words[3] = {"PAPER", "SCISSORS", "ROCK"};
static char choice_chars[3] = {'P', 'S', 'R'};
char result = 'N';

/* Time delayer */
void timer_delay (void)
{
    TCNT1 = 0;
    while (TCNT1 < (3906/30)) {
        continue;
    }
    TCNT1 = 0;
}

/* Create figure - paper */
void draw_paper (void)
{
    tinygl_draw_point (tinygl_point (0, 2), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 0), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 0), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (3, 0), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 3), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 1), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
}

/* Create figure - scissors */
void draw_scissors (void)
{
    tinygl_draw_point (tinygl_point (0, 0), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 2), 1);
    tinygl_draw_point (tinygl_point (2, 3), 1);
    tinygl_draw_point (tinygl_point (3, 1), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 4), 1);
    tinygl_draw_point (tinygl_point (3, 5), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (4, 6), 1);
}

/* Create figure - rock */
void draw_rock (void)
{
    tinygl_draw_point (tinygl_point (4, 3), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (2, 1), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
}

/* Navigational switch creater */
void get_nav_event (void)
{
    /* if the navigational switch switch to west, change choice */
        if (navswitch_push_event_p (NAVSWITCH_WEST)) {
            words = (words + 1) % 2; // modulo function switcher
            tinygl_clear ();
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
    /* if the navigational switch switch to east, change choice */
        if (navswitch_push_event_p (NAVSWITCH_SOUTH)) {
            if (bitmap_shape > 0) {
                bitmap_shape--;
                tinygl_clear ();
            }
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
    /* if the navigational switch switch to north, change choice */
        if (navswitch_push_event_p (NAVSWITCH_NORTH)) {
            if (bitmap_shape < 2) {
                bitmap_shape++;
                tinygl_clear ();
            }
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
    /* if the navigational switch is pushed, submit */
        if (navswitch_push_event_p (NAVSWITCH_PUSH)) {
            if (player_1 == 1) { // if player 1
                player_1_choice = choice_chars[bitmap_shape];
            } else if (player_2 == 1) {  // if player 2
                player_2_choice = choice_chars[bitmap_shape];
            }
        }
}

/* Display Bitmap */
void show_display (void)
{
    if (words == 0) {
        /* show figures for each operation placed for paper, scissors and rock */
        /* while indedx == 0, draw paper */
            if (bitmap_shape == 0) {
                draw_paper ();
        /* while indedx == 1, draw scissors */
            } else if (bitmap_shape == 1) {
                draw_scissors ();
        /* while indedx == 2, draw rock */
            } else if (bitmap_shape == 2) {
                draw_rock ();
            }
    }
}

/* Sender */
void send_choice (void)
{
    /* if the first player */
    if (player_1 == 1) {
        ir_uart_putc (player_1_choice);
    } else if (player_2 == 1) {
        ir_uart_putc (player_2_choice);
    }
}

/* Reciever */
void recieve_choice (void)
{
    tinygl_clear ();
    tinygl_text ("RECIEVING");
    if (player_1 == 1) {
        while (player_2_choice == 'N') {
            pacer_wait ();
            tinygl_update ();
            if (ir_uart_read_ready_p ())
            {
                player_2_choice = ir_uart_getc ();
                tinygl_clear ();
            }
        }
    } else if (player_2 == 1) {
        while (player_1_choice == 'N') {
            pacer_wait ();
            tinygl_update ();
            if (ir_uart_read_ready_p ())
            {
                player_1_choice = ir_uart_getc ();
                tinygl_clear ();
            }
        }
    }
    tinygl_text ("");
    tinygl_update ();
}


/* Winner calculator */
char* calculate_winner (void)
{
    tinygl_text ("");
    tinygl_clear ();
    tinygl_update ();
    char* display_text = "";
    if (player_1 == 1) {
        if ((player_1_choice == 'P' && player_2_choice == 'R') || (player_1_choice == 'S' && player_2_choice == 'P') || (player_1_choice == 'P' && player_2_choice == 'R')) {//You Won
            display_text = "WINNER";
            result = 'W';
        } else if (player_1_choice == player_2_choice) {
            display_text = "DRAW";
            result = 'D';
        } else {
            display_text = "LOSER";
            result = 'L';
        }
    } else if (player_2 == 1) {
       if ((player_1_choice == 'P' && player_2_choice == 'R') || (player_1_choice == 'S' && player_2_choice == 'P') || (player_1_choice == 'P' && player_2_choice == 'R')) {//You Won
            display_text = "LOSER";
            result = 'W';
        } else if (player_1_choice == player_2_choice) {
            display_text = "DRAW";
            result = 'D';
        } else {
            display_text = "WINNER";
            result = 'L';
        }
    }
    return display_text;
}

/* button initializer */
void button_init (void)
{
    DDRD &= ~BIT(7);
}

/* button pressed */
int button_pressed_p (void)
{
    return (PIND & BIT(7));
}

/* Reset game */
void reset_game (void)
{
    bitmap_shape = 0;
    words = 0;
    player_1_choice = 'N';//CHANGE ALL SINGLE CHARS TO CHAR
    player_2_choice = 'N';
    player_1 = 0;
    player_2 = 0;
}

/* Player chooser */
void decide_player (void)
{
    tinygl_text ("PRESS FOWARD");
    while (player_1 == 0 && player_2 == 0)
    {
        pacer_wait ();
        tinygl_update ();
        navswitch_update ();
        if (navswitch_push_event_p (NAVSWITCH_WEST)) {
            ir_uart_putc ('P');
            player_1 = 1;
            break;
        } else if (ir_uart_read_ready_p ()) {
            char recieved_data = ir_uart_getc ();
            if (recieved_data == 'P') {
                player_2 = 1;
                break;
            }
        }
    }
    /* Initing who is player 1 and who is player 2 */
    /*  reset text  */
    tinygl_text (""); 
    tinygl_clear ();
    tinygl_update ();
}

/* Player Updates*/
void updates (void)
{
    pacer_wait ();
    tinygl_update ();
    navswitch_update ();
    get_nav_event ();
    show_display ();
    
}


/* Player Communication logic definer */
void player_logic (void)
{
    if (player_1 == 1) {
            while (player_1_choice == 'N') {
                updates ();
            }
            send_choice ();
            recieve_choice ();
        } else if (player_2 == 1) {
            recieve_choice ();
            while (player_2_choice == 'N') {
                updates ();
            }
            send_choice ();
    }
}

/* Winner displayer */
void display_winner (void)
{
        uint8_t display = 1;
        int tick = 0;
            /*  if the player win or lose change  the volume of the beeper */
        if (result == 'W') {
            TONE_FREQUENCY = 100;
        } else if (result == 'L') {
            TONE_FREQUENCY = 5;
        }
        while (display == 1) {
            if (result != 'D') {
                pio_output_toggle (TEST_PIO);
                tick = tick + 1;
                if (tick >= (LOOP_RATE / (TONE_FREQUENCY * 2)))
                {
                    tick = 0;
                    pio_output_toggle (PIEZO1_PIO);
                    pio_output_toggle (PIEZO2_PIO);
                }
            }
            
            if (navswitch_push_event_p (NAVSWITCH_EAST)) {
                display = 0;
                reset_game ();
                ir_uart_putc ('R');
            } else if (ir_uart_read_ready_p ())
            {
                char reset = ir_uart_getc ();
                if (reset == 'R') {
                display = 0;
                reset_game ();
                }
            }
            pacer_wait ();
            tinygl_update ();
            navswitch_update ();
        }
        pio_config_set (PIEZO2_PIO, PIO_OUTPUT_LOW);
}

/* set text  */
void set_text(void)
{   
    tinygl_init (PACER_RATE);
    tinygl_font_set (&font3x5_1);
    tinygl_text_speed_set (20);
    tinygl_text_mode_set (TINYGL_TEXT_MODE_SCROLL);
    tinygl_text_dir_set (TINYGL_TEXT_DIR_ROTATE);
}

/* set configurations  */
void set_configure (void) 
{
    pio_config_set (PIEZO1_PIO, PIO_OUTPUT_LOW);
    pio_config_set (PIEZO2_PIO, PIO_OUTPUT_LOW);
    pio_config_set (TEST_PIO, PIO_OUTPUT_HIGH);
    
}



int main (void)
{
    /*    set configurations */
    set_configure ();
    system_init ();
    pacer_init (500);

    set_text();

    navswitch_init ();
    ir_uart_init ();
    TCNT1 = 0;
    pacer_init (PACER_RATE);
    
    while (1)
    {
        decide_player ();
        pacer_wait ();
        tinygl_update ();
        player_logic ();
        tinygl_text (calculate_winner ());
        display_winner ();
    }
    return (0);
}
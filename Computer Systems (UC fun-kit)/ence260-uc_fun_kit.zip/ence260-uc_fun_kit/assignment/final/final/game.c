#include "system.h"
#include "pio.h"
#include "pacer.h"
#include "navswitch.h"
#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font3x5_1.h"


#define PACER_RATE 500
#define MESSAGE_RATE 10

uint8_t bitmap_shape = 0;
uint8_t words = 0;
char player_1_choice = 'N';//CHANGE ALL SINGLE CHARS TO CHAR
char player_2_choice = 'N';
uint8_t player_1 = 0;
uint8_t player_2 = 0;


void timer_delay (void)
{
    TCNT1 = 0;
    while (TCNT1 < (3906/30)) {
        continue;
    }
    TCNT1 = 0;
}

static uint8_t previous_col=5;
/** Define PIO pins driving LED matrix rows.  */
static const pio_t rows[] =
{
    LEDMAT_ROW1_PIO, LEDMAT_ROW2_PIO, LEDMAT_ROW3_PIO,
    LEDMAT_ROW4_PIO, LEDMAT_ROW5_PIO, LEDMAT_ROW6_PIO,
    LEDMAT_ROW7_PIO
};


/** Define PIO pins driving LED matrix columns.  */
static const pio_t cols[] =
{
    LEDMAT_COL1_PIO, LEDMAT_COL2_PIO, LEDMAT_COL3_PIO,
    LEDMAT_COL4_PIO, LEDMAT_COL5_PIO
};
static char* choice_words[3] = {"PAPER", "SCISSORS", "ROCK"};
static char choice_chars[3] = {'P', 'S', 'R'};


static uint8_t bitmap[][5] =
{
    {0b1101100,
    0b1010011,
    0b1000001,
    0b1001101,
    0b0110011},

    {0b1110001,
    0b1110110,
    0b0001100,
    0b1110110,
    0b1110001},

    {0b00111000,
    0b1000100,
    0b1000010,
    0b0110100,
    0b0011000}
};





static uint8_t clear[] =
{
    0b0,
    0b0,
    0b0,
    0b0,
    0b0
};



static void display_column (uint8_t row_pattern, uint8_t current_column)
{
   pio_output_high(cols[previous_col]);
   pio_output_low(cols[current_column]);
    /* TODO */
    uint8_t current_row=0;
    for (current_row; current_row < LEDMAT_ROWS_NUM; current_row++){
        if((row_pattern >> current_row) & 1)
        {
            pio_output_low(rows[current_row]);
        }else{
            pio_output_high(rows[current_row]);
        }

    }
    previous_col=current_column;

}
void clear_display (void)
{
    uint8_t current_column = 0;
    while (current_column < (LEDMAT_COLS_NUM)) {
        display_column (clear[current_column], current_column);
        current_column++;
    }
}
void display_character (char character)
{
    char buffer[2];
    buffer[0] = character;
    buffer[1] = '\0';
    tinygl_text (buffer);
}

void draw_paper (void)
{
    tinygl_draw_point (tinygl_point (0, 2), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 0), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 0), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (3, 0), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 3), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 1), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
}

void draw_scissors (void)
{
    tinygl_draw_point (tinygl_point (0, 0), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 2), 1);
    tinygl_draw_point (tinygl_point (2, 3), 1);
    tinygl_draw_point (tinygl_point (3, 1), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 4), 1);
    tinygl_draw_point (tinygl_point (3, 5), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (4, 6), 1);
}

void draw_rock (void)
{
    tinygl_draw_point (tinygl_point (4, 3), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (2, 1), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
}

void get_nav_event (void)
{
        if (navswitch_push_event_p (NAVSWITCH_WEST)) {
            words = (words + 1) % 2;
            tinygl_clear ();
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
        if (navswitch_push_event_p (NAVSWITCH_SOUTH)) {
            if (bitmap_shape > 0) {
                bitmap_shape--;
                tinygl_clear ();
            }
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
        if (navswitch_push_event_p (NAVSWITCH_NORTH)) {
            if (bitmap_shape < 2) {
                bitmap_shape++;
                tinygl_clear ();
            }
            if (words == 1) {
                tinygl_text (choice_words[bitmap_shape]);
            }
        }
        if (navswitch_push_event_p (NAVSWITCH_PUSH)) {
            if (player_1 == 1) {
                player_1_choice = choice_chars[bitmap_shape];
            } else if (player_2 == 1) {
                player_2_choice = choice_chars[bitmap_shape];
            }
        }
}

void show_display (void)
{
    if (words == 0) {
            if (bitmap_shape == 0) {
                draw_paper ();
            } else if (bitmap_shape == 1) {
                draw_scissors ();
            } else if (bitmap_shape == 2) {
                draw_rock ();
            }
    }
}

void send_choice (void)
{
    if (player_1 == 1) {
        ir_uart_putc (player_1_choice);
    } else if (player_2 == 1) {
        ir_uart_putc (player_2_choice);
    }
}

void recieve_choice (void)
{
    tinygl_clear ();
    tinygl_text ("RECIEVING");
    if (player_1 == 1) {
        while (player_2_choice == 'N') {
            pacer_wait ();
            tinygl_update ();
            if (ir_uart_read_ready_p ())
            {
                player_2_choice = ir_uart_getc ();
                tinygl_clear ();
            }
        }
    } else if (player_2 == 1) {
        while (player_1_choice == 'N') {
            pacer_wait ();
            tinygl_update ();
            if (ir_uart_read_ready_p ())
            {
                player_1_choice = ir_uart_getc ();
                tinygl_clear ();
            }
        }
    }
    tinygl_text ("");
    tinygl_update ();
}



char* calculate_winner ()
{
    tinygl_text ("");
    tinygl_clear ();
    tinygl_update ();
    if (player_1 == 1) {
        if ((player_1_choice == 'P' && player_2_choice == 'R') || (player_1_choice == 'S' && player_2_choice == 'P') || (player_1_choice == 'R' && player_2_choice == 'P')) {//You Won
            return "WINNER";
        } else if (player_1_choice == player_2_choice) {
            return "DRAW";
        } else {
            return "LOSER";
        }
    } else if (player_2 == 1) {
       if ((player_1_choice == 'P' && player_2_choice == 'R') || (player_1_choice == 'S' && player_2_choice == 'P') || (player_1_choice == 'R' && player_2_choice == 'P')) {//You Won
            return "LOSER";
        } else if (player_1_choice == player_2_choice) {
            return "DRAW";
        } else {
            return "WINNER";
        }
    }
}


void button_init (void)
{
    DDRD &= ~BIT(7);
}

int button_pressed_p (void)
{
    return (PIND & BIT(7));
}

void reset_game (void)
{
    bitmap_shape = 0;
    words = 0;
    player_1_choice = 'N';//CHANGE ALL SINGLE CHARS TO CHAR
    player_2_choice = 'N';
    player_1 = 0;
    player_2 = 0;
}

void decide_player (void)
{
    tinygl_text ("PRESS");
    while (player_1 == 0 && player_2 == 0)
    {
        pacer_wait ();
        tinygl_update ();
        navswitch_update ();
        if (navswitch_push_event_p (NAVSWITCH_WEST)) {
            ir_uart_putc ('P');
            player_1 = 1;
            break;
        } else if (ir_uart_read_ready_p ())
        {
            char recieved_data = ir_uart_getc ();
            if (recieved_data == 'P') {
                player_2 = 1;
                break;
            }
        }
    }
    //Initing who is player 1 and who is player 2
    tinygl_text ("");//MAking it blank again
    tinygl_clear ();
    tinygl_update ();
}

void player_logic (void)
{
    if (player_1 == 1) {
            while (player_1_choice == 'N') {
                pacer_wait ();
                tinygl_update ();
                navswitch_update ();
                get_nav_event ();
                show_display ();
            }
            send_choice ();
            recieve_choice ();
        } else if (player_2 == 1) {
            recieve_choice ();
            while (player_2_choice == 'N') {
                pacer_wait ();
                tinygl_update ();
                navswitch_update ();
                get_nav_event ();
                show_display ();
            }
            send_choice ();
    }
}

void display_winner (void)
{

        uint8_t display = 1;
        while (display == 1) {
            if (navswitch_push_event_p (NAVSWITCH_EAST)) {
                display = 0;
                reset_game ();
                ir_uart_putc ('R');
            } else if (ir_uart_read_ready_p ())
            {
                char reset = ir_uart_getc ();
                if (reset == 'R') {
                display = 0;
                reset_game ();
                }
            }
            pacer_wait ();
            tinygl_update ();
            navswitch_update ();
        }
}

int main (void)
{
    DDRC |= BIT(2);//led init
    system_init ();
    pacer_init (500);
    timer_init ();
    button_init ();
    char character = 'A';

    tinygl_init (PACER_RATE);
    tinygl_font_set (&font3x5_1);
    tinygl_text_speed_set (20);
    tinygl_text_mode_set (TINYGL_TEXT_MODE_SCROLL);
    tinygl_text_dir_set (TINYGL_TEXT_DIR_ROTATE);


    navswitch_init ();
    ir_uart_init ();
    TCCR1A = 0x00;
    TCCR1B = 0x05;
    TCCR1C = 0x00;//INITING IT TO NOTHING SO IT DOESNT MESS UP SCREEN
    TCNT1 = 0;
    pacer_init (PACER_RATE);
    while (1)
    {
        decide_player ();
        pacer_wait ();
        tinygl_update ();
        player_logic ();
        tinygl_text (calculate_winner ());
        display_winner ();
    }
}

/** 
 * @file game.c
 * @author  Caleb Wenborn (cwe55)  
 *          Chang Tu (ctu28)  
 * Team number : 422
 *
 * @date   16 October 2018
**/


#include "system.h"
#include "pio.h"
#include "pacer.h"
#include "navswitch.h"
#include "ir_uart.h"
#include "tinygl.h"
#include "../fonts/font3x5_1.h"


#ifndef displays_H
#define displays_H
 
void draw_paper(void);
void draw_scissors(void);
void draw_rock(void);
 
#endif /* displays_H */

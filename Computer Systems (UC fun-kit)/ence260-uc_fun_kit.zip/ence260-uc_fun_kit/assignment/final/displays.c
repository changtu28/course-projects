/** 
 * @file game.c
 * @author  Caleb Wenborn (cwe55)  
 *          Chang Tu (ctu28)  
 * Team number : 422
 *
 * @date   16 October 2018
**/


/* Create figure - paper */
void draw_paper (void)
{
    tinygl_draw_point (tinygl_point (0, 2), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 0), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 0), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (3, 0), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 3), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 1), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
}

/* Create figure - scissors */
void draw_scissors (void)
{
    tinygl_draw_point (tinygl_point (0, 0), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
    tinygl_draw_point (tinygl_point (0, 5), 1);
    tinygl_draw_point (tinygl_point (0, 6), 1);
    tinygl_draw_point (tinygl_point (1, 1), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (1, 6), 1);
    tinygl_draw_point (tinygl_point (2, 2), 1);
    tinygl_draw_point (tinygl_point (2, 3), 1);
    tinygl_draw_point (tinygl_point (3, 1), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 4), 1);
    tinygl_draw_point (tinygl_point (3, 5), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (4, 0), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (4, 6), 1);
}

/* Create figure - rock */
void draw_rock (void)
{
    tinygl_draw_point (tinygl_point (4, 3), 1);
    tinygl_draw_point (tinygl_point (4, 4), 1);
    tinygl_draw_point (tinygl_point (4, 5), 1);
    tinygl_draw_point (tinygl_point (3, 2), 1);
    tinygl_draw_point (tinygl_point (3, 6), 1);
    tinygl_draw_point (tinygl_point (2, 1), 1);
    tinygl_draw_point (tinygl_point (2, 6), 1);
    tinygl_draw_point (tinygl_point (1, 2), 1);
    tinygl_draw_point (tinygl_point (1, 4), 1);
    tinygl_draw_point (tinygl_point (1, 5), 1);
    tinygl_draw_point (tinygl_point (0, 3), 1);
    tinygl_draw_point (tinygl_point (0, 4), 1);
}
